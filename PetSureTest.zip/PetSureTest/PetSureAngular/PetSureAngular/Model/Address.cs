﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetSureAngular.Model
{
    public class Address
    {
        public string Street { get; set; }
        public int PostCode { get; set; }
        public string City { get; set; }
    }
}
