﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PetSureAngular.Model;

namespace PetSureAngular.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;

        public CustomerController(ILogger<CustomerController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<IEnumerable<Customer>> Get()
        {
            //start PetSureApi project first then run PetSureAngular project
            
            List<Customer> reservationList = new List<Customer>();

            var userName = "PetSure";
            var passwd = "PetSure";
            var url = "https://localhost:44391/Customer/GetAllCustomers";
            //Call web api to get all customers' information
            using (var client = new HttpClient())
            {
                var authToken = Encoding.ASCII.GetBytes($"{userName}:{passwd}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                        Convert.ToBase64String(authToken));

                var result = await client.GetAsync(url);

                var content = await result.Content.ReadAsStringAsync();
                reservationList = JsonConvert.DeserializeObject<List<Customer>>(content);
            }
            return reservationList;
        }
    }
}
