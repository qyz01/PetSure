﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetSureApi.Auth;
using PetSureApi.Data;
using PetSureApi.Model;

namespace PetSureApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly IRepository _repo;
        private readonly IUserService _userService;

        public CustomerController(IRepository repo, IUserService userService)
        {
            _repo = repo ?? throw new ArgumentNullException(nameof(Repository));
            _userService = userService ?? throw new ArgumentNullException(nameof(UserService));
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody] AuthenticateModel model)
        {
            var user = await _userService.Authenticate(model.Username, model.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(user);
        }

        [HttpGet("GetAllCustomers")]
        public List<Customer> GetAllCustomers()
        {
            try
            {
                var clist = _repo.GetCustomers();
                foreach (var c in clist)
                    if (!c.MulpleAddresses)
                        c.IsPremiumCustomer = c.Addresses.First().City == "Chatswood";
                    else
                        c.IsPremiumCustomer = c.Addresses.Exists(x => x.City == "Chatswood");

                return clist;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet("GetDetailsById")]
        public Customer GetDetailsById(int id)
        {
            try
            {
                return _repo.GetCustomer(id) ?? null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost("Insertd")]
        public bool Insertd([FromBody] Customer customer)
        {
            try
            {
                return _repo.Add(customer);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [HttpPost("Delete")]
        public bool Delete(int id)
        {
            try
            {
                return _repo.Delete(id);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
