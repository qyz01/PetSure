﻿using PetSureApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetSureApi.Data
{
    public class Repository : IRepository
    {

        private List<Customer> cList = new List<Customer>
            {
                new Customer { Id=1, FirstName="F_Test1", LastName="L_Test1", DateOfBirth= DateTime.Parse("01-01-1980"), IsPremiumCustomer=false, MulpleAddresses=false, Addresses=new List<Address> { new Address { City="Chatswood", PostCode=2067, Street="Help"} } },
                new Customer { Id=2, FirstName="F_Test2", LastName="L_Test2", DateOfBirth= DateTime.Parse("02-02-1990"), IsPremiumCustomer=false, MulpleAddresses=false, Addresses=new List<Address> { new Address { City="Sydney", PostCode=2000, Street="Clarence"} } }
            };
        public List<Customer> GetCustomers()
        {
            return cList;
        }

        public Customer GetCustomer(int id)
        {
            return cList.First(x => x.Id == id);
        }

        public bool Add(Customer customer)
        {
            try
            {
                cList.Add(customer);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool Delete(int id)
        {
            try
            {
                cList.RemoveAll(x => x.Id == id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
