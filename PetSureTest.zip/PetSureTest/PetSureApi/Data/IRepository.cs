﻿using PetSureApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetSureApi.Data
{
    public interface IRepository
    {
        public List<Customer> GetCustomers();
        public Customer GetCustomer(int id);

        public bool Add(Customer customer);
        public bool Delete(int id);
    }
}
